from flask import Flask, render_template, request
import boto3
import oracledb


app = Flask(__name__)

ALLOWED_TABLES = [
    'Branch_ID_Master', 'City_Master', 'Loan_Details_transactions',
    'Loan_status_mapping', 'Postal_Code_Master', 'Region_Master',
    'State_Master', 'State_Region_Mapping'
]
 
def get_db_connection():
    # Update these values with your actual database credentials
    dsn = oracledb.makedsn("localhost", "1521", service_name="xepdb1")
    conn = oracledb.connect(user="dbuser", password="dbuser", dsn=dsn)
    return conn
 
@app.route('/')
def index():
    return render_template('index1.html', tables=ALLOWED_TABLES)
 
@app.route('/show_table', methods=['POST'])
def show_table():
    selected_table = request.form.get('table_name')
    if selected_table not in ALLOWED_TABLES:
        return "Invalid table selection", 400
   
    conn = get_db_connection()
    cursor = conn.cursor()
 
    # Fetch the data from the selected table
    cursor.execute(f"SELECT * FROM {selected_table}")
    columns = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()
 
    cursor.close()
    conn.close()
 
    return render_template('table1.html', columns=columns, rows=rows, table_name=selected_table)
@app.route('/fire_query', methods = ['GET','POST'])
def fire_query():
    selected_table = request.form.get('table_name')
    primary_key = request.form.get('primary_key')
    print(selected_table , ' ', primary_key)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(f"select * from {selected_table}")
    columns = [desc[0] for desc in cursor.description]
 
 
    cursor.execute(f"select * from {selected_table} where {columns[0]} = {primary_key}")
    columns = [desc[0] for desc in cursor.description]
    row = cursor.fetchall()
    cursor.close()
    conn.close()
 
    return render_template('table1.html', columns = columns, rows = row, table_name = selected_table)
 
if __name__ == '__main__':
    app.run(debug=True)